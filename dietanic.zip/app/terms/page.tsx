'use client';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { motion } from 'motion/react';
import { BadgeCheck, CalendarCheck, ShieldAlert, Copyright, Scale, Landmark } from 'lucide-react';

export default function TermsOfService() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-32 pb-20 bg-emerald-50/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-emerald-950 mb-6">Terms of Service</h1>
            <p className="text-emerald-800/70 text-lg mb-8">
              Last Updated: March 7, 2026
            </p>
            <div className="h-1 w-20 bg-emerald-500 rounded-full mb-12" />
          </motion.div>
        </div>
      </div>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-emerald max-w-none space-y-16">
            
            {/* Eligibility */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
                  <BadgeCheck className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">1. Eligibility</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  To access the services provided by Dietanic, you must meet the following criteria:
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Age Requirement:</strong> You must be at least 18 years of age. By registering, you represent and warrant that you have the legal capacity to enter into a binding agreement.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Minors:</strong> Users under 18 may only use our services under the strict supervision of a parent or legal guardian who agrees to be bound by these Terms.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Account Security:</strong> You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Subscription Terms & Commitment */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                  <CalendarCheck className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">2. Subscription Terms &amp; Commitment</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-6">
                  By choosing a Dietanic Subscription, you are making a commitment to your health journey.
                </p>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                    <h4 className="font-bold text-blue-900 text-sm mb-1">Plan Durations</h4>
                    <p className="text-xs text-blue-800/80">Subscriptions are offered in various tiers (e.g., Monthly, Quarterly, or Semi-Annual).</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                    <h4 className="font-bold text-blue-900 text-sm mb-1">The Commitment Aspect</h4>
                    <p className="text-xs text-blue-800/80">Our plans are designed for consistency. By subscribing, you agree to the full duration of the chosen term.</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                    <h4 className="font-bold text-blue-900 text-sm mb-1">Auto-Renewal</h4>
                    <p className="text-xs text-blue-800/80">Subscriptions may automatically renew at the end of the term unless cancelled at least <strong>48 hours</strong> prior to the renewal date.</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                    <h4 className="font-bold text-blue-900 text-sm mb-1">EMI Obligations</h4>
                    <p className="text-xs text-blue-800/80">If you opt for EMI payments, you are committed to completing the full payment cycle as per the agreement with our financial partners.</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* User Conduct */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600">
                  <ShieldAlert className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">3. User Conduct</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  Users agree to use the Dietanic platform solely for lawful purposes. You are <strong>strictly prohibited</strong> from:
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed">Engaging in fraudulent activities or misrepresenting your identity.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed">Attempting to bypass website security or reverse-engineer our platform.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed">Using our dietary plans for commercial resale or unauthorized distribution.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed">Providing false health data that could compromise the safety of the personalized plans provided.</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Intellectual Property */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600">
                  <Copyright className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">4. Intellectual Property</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  All content on this platform, including but not limited to the Dietanic brand name, logos, website design, proprietary diet charts, nutritional algorithms, and text, is the exclusive intellectual property of <strong>CULTLIV DIETANIC LLP</strong>.
                </p>
                <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                  <p className="text-sm text-purple-900/80 leading-relaxed">
                    Unauthorized use, reproduction, or distribution of our intellectual property is strictly prohibited and may result in legal action.
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Limitation of Liability */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600">
                  <Scale className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">5. Limitation of Liability</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  CULTLIV DIETANIC LLP and its partners shall not be liable for any indirect, incidental, or consequential damages arising from the use of our services.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>No Guarantees:</strong> While we strive for excellence, Dietanic does not guarantee specific weight loss or health outcomes, as results vary based on individual physiology and adherence to the plans.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Liability Cap:</strong> Our total liability for any claim shall not exceed the amount paid by you for the service in question.</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Governing Law & Jurisdiction */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600">
                  <Landmark className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">6. Governing Law &amp; Jurisdiction</h2>
                <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
                  <p className="text-indigo-900/80 leading-relaxed mb-4">
                    These Terms shall be governed by and construed in accordance with the laws of <strong>India</strong>.
                  </p>
                  <p className="text-indigo-900/80 leading-relaxed">
                    Any disputes arising out of or in connection with these terms shall be subject to the exclusive jurisdiction of the courts located in <strong>Coimbatore, Tamil Nadu, India</strong>, where CULTLIV DIETANIC LLP is officially registered.
                  </p>
                </div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
