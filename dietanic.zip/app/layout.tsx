import type {Metadata} from 'next';
import { Inter, Space_Grotesk } from 'next/font/google';
import './globals.css'; // Global styles

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-display',
});

export const metadata: Metadata = {
  title: 'Dietanic | Fresh Fruit Salad & Healthy Meal Delivery in Coimbatore',
  description: 'Get fresh fruit bowls and healthy salads delivered daily in Coimbatore. Subscribe to our nutritious meal plans for weight loss, fitness, and clean eating. Free morning delivery.',
  openGraph: {
    title: 'Dietanic | Fresh Fruit Salad & Healthy Meal Delivery in Coimbatore',
    description: 'Get fresh fruit bowls and healthy salads delivered daily in Coimbatore. Subscribe to our nutritious meal plans for weight loss, fitness, and clean eating. Free morning delivery.',
    url: 'https://dietanic.co',
    siteName: 'Dietanic',
    images: [
      {
        url: 'https://picsum.photos/seed/dietanic/1200/630',
        width: 1200,
        height: 630,
        alt: 'Dietanic Premium Fruit & Salad Delivery',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable} scroll-smooth`}>
      <body className="font-sans antialiased" suppressHydrationWarning>{children}</body>
    </html>
  );
}
