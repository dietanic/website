import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import Benefits from '@/components/Benefits';
import Pricing from '@/components/Pricing';
import Ingredients from '@/components/Ingredients';
import InteractiveTools from '@/components/InteractiveTools';
import DeliveryZone from '@/components/DeliveryZone';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import Testimonials from '@/components/Testimonials';

export default function Home() {
  return (
    <main className="min-h-screen bg-white selection:bg-emerald-200 selection:text-emerald-900">
      <Navbar />
      <Hero />
      <Features />
      <Benefits />
      <Pricing />
      <Ingredients />
      <InteractiveTools />
      <Testimonials />
      <DeliveryZone />
      <FAQ />
      <Footer />
      <WhatsAppButton />
    </main>
  );
}
