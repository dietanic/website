'use client';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { motion } from 'motion/react';
import { AlertTriangle, Info, Activity, ShieldAlert } from 'lucide-react';

export default function MedicalDisclaimer() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-32 pb-20 bg-emerald-50/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-emerald-950 mb-6">Medical Disclaimer</h1>
            <p className="text-emerald-800/70 text-lg mb-8">
              Last Updated: March 7, 2026
            </p>
            <div className="h-1 w-20 bg-emerald-500 rounded-full mb-12" />
          </motion.div>
        </div>
      </div>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-emerald max-w-none space-y-16">
            
            {/* Assumption of Risk */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600">
                  <AlertTriangle className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">1. Assumption of Risk</h2>
                <p className="text-emerald-800/80 leading-relaxed">
                  By using our services and committing to our plans, you acknowledge that you are doing so voluntarily and at your own risk. You should consult a doctor before starting any new dietary regime, especially if you are pregnant, nursing, or have a pre-existing medical condition.
                </p>
              </div>
            </motion.div>

            {/* Allergies & Sensitivities */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600">
                  <ShieldAlert className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">2. Allergies & Sensitivities</h2>
                <p className="text-emerald-800/80 leading-relaxed">
                  While we provide ingredient lists, our products are prepared in facilities that handle common allergens (nuts, dairy, gluten, etc.). It is the user’s responsibility to review ingredients for potential allergens. Dietanic is not liable for adverse reactions resulting from undisclosed or ignored food sensitivities.
                </p>
              </div>
            </motion.div>

            {/* Individual Results */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                  <Activity className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">3. Individual Results</h2>
                <p className="text-emerald-800/80 leading-relaxed">
                  Health outcomes, including weight loss or muscle gain, vary from person to person. CULTLIV DIETANIC LLP does not guarantee specific results. Success depends on various factors including age, genetics, physical activity, and strict adherence to the diet plan.
                </p>
              </div>
            </motion.div>

            {/* Not Medical Advice */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600">
                  <Info className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">4. Not Medical Advice</h2>
                <p className="text-emerald-800/80 leading-relaxed">
                  The content, products, and meal plans provided by Dietanic are for informational and nutritional purposes only. They do not constitute professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health providers with any questions you may have regarding a medical condition.
                </p>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
