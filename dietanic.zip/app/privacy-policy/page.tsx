'use client';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { motion } from 'motion/react';
import { Shield, Database, Activity, Users, Cookie, Target, Trash2 } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-32 pb-20 bg-emerald-50/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-emerald-950 mb-6">Privacy Policy</h1>
            <p className="text-emerald-800/70 text-lg mb-8">
              Last Updated: March 7, 2026
            </p>
            <div className="h-1 w-20 bg-emerald-500 rounded-full mb-12" />
          </motion.div>
        </div>
      </div>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-emerald max-w-none space-y-16">
            
            {/* Information Collection */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
                  <Database className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">1. Information Collection</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-6">
                  At Dietanic, we collect only the information necessary to provide you with a high-quality, personalized health experience. This includes:
                </p>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                    <h4 className="font-bold text-emerald-900 text-sm mb-1">Personal Identity</h4>
                    <p className="text-xs text-emerald-800/70">Name, email address, and phone number.</p>
                  </div>
                  <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                    <h4 className="font-bold text-emerald-900 text-sm mb-1">Health & Physical Data</h4>
                    <p className="text-xs text-emerald-800/70">BMI, age, weight, dietary preferences, and fitness goals.</p>
                  </div>
                  <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                    <h4 className="font-bold text-emerald-900 text-sm mb-1">Logistics Data</h4>
                    <p className="text-xs text-emerald-800/70">Physical shipping address for delivery of your subscription plans.</p>
                  </div>
                  <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                    <h4 className="font-bold text-emerald-900 text-sm mb-1">Financial Information</h4>
                    <p className="text-xs text-emerald-800/70">Payment details collected via secure, encrypted channels.</p>
                  </div>
                </div>
                <p className="text-sm text-emerald-800/60 mt-4 italic">
                  * Data is collected automatically when you access our site using cookies, log files, web beacons, tags, or pixels.
                </p>
              </div>
            </motion.div>

            {/* Usage of Data */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                  <Activity className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">2. Usage of Data</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  We use the information we collect to power your &quot;Commitment to Health&quot;:
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Personalization:</strong> Your health and BMI data are used by our algorithms and nutritionists to curate meal plans specific to your body’s needs.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Service Updates:</strong> To send you subscription renewals, EMI reminders, and delivery tracking.</p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                    <p className="text-emerald-800/80 text-sm leading-relaxed"><strong>Internal Research:</strong> To analyze trends and improve the efficacy of our dietary products.</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Data Security */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600">
                  <Shield className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">3. Data Security</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  We take the security of your sensitive health and financial information seriously:
                </p>
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                    <h4 className="font-bold text-purple-900 mb-1">Encryption</h4>
                    <p className="text-sm text-purple-800/80">We use industry-standard SSL/TLS encryption for all data transmissions.</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                    <h4 className="font-bold text-purple-900 mb-1">Access Control</h4>
                    <p className="text-sm text-purple-800/80">Access to your health data is restricted to authorized personnel who need it to design your plans.</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                    <h4 className="font-bold text-purple-900 mb-1">Secure Storage</h4>
                    <p className="text-sm text-purple-800/80">Your data is stored on secure servers with robust firewalls to prevent unauthorized access or data breaches.</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Third-Party Sharing */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600">
                  <Users className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">4. Third-Party Sharing</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-6">
                  We respect your privacy and <strong>do not sell your data</strong>. However, we share necessary information with trusted partners to fulfill our services:
                </p>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="bg-orange-50 p-4 rounded-2xl border border-orange-100">
                    <h4 className="font-bold text-orange-900 text-sm mb-2">Payment Gateways</h4>
                    <p className="text-xs text-orange-800/80">Financial data is processed through secure partners like Razorpay or Zoho Payments.</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-2xl border border-orange-100">
                    <h4 className="font-bold text-orange-900 text-sm mb-2">Logistics Partners</h4>
                    <p className="text-xs text-orange-800/80">Your name, address, and contact number are shared with delivery services to get your products to you.</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-2xl border border-orange-100">
                    <h4 className="font-bold text-orange-900 text-sm mb-2">Financing Partners</h4>
                    <p className="text-xs text-orange-800/80">If you opt for EMI plans, relevant data is shared with our lending partners to process your credit application.</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Cookies & Tracking */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-yellow-100 rounded-2xl flex items-center justify-center text-yellow-600">
                  <Cookie className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">5. Cookies & Tracking</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  Our website uses cookies and similar tracking technologies to enhance your browsing experience. This allows us to:
                </p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-emerald-800/80">
                    <div className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                    Remember your login details so you don&apos;t have to re-enter them.
                  </li>
                  <li className="flex items-center gap-2 text-sm text-emerald-800/80">
                    <div className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                    Understand which parts of the Dietanic platform you visit most often.
                  </li>
                  <li className="flex items-center gap-2 text-sm text-emerald-800/80">
                    <div className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                    Provide relevant health content and subscription offers based on your interests.
                  </li>
                </ul>
                <p className="text-sm text-emerald-800/60 italic">
                  You can manage or disable cookies through your browser settings, though some site features may become unavailable.
                </p>
              </div>
            </motion.div>

            {/* Behavioral Advertising */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600">
                  <Target className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">6. Behavioral Advertising</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  We use your Personal Information to provide you with targeted advertisements or marketing communications we believe may be of interest to you.
                </p>
                <div className="space-y-4">
                  <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100">
                    <p className="text-sm text-indigo-900/80 leading-relaxed mb-2">
                      <strong>Google Analytics:</strong> We use Google Analytics to help us understand how our customers use the Site.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-2 text-xs">
                      <a href="https://www.google.com/intl/en/policies/privacy/" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">Read Google&apos;s Privacy Policy</a>
                      <span className="hidden sm:inline text-indigo-300">|</span>
                      <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">Opt-out of Google Analytics</a>
                    </div>
                  </div>
                  <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100">
                    <p className="text-sm text-indigo-900/80 leading-relaxed mb-2">
                      <strong>Social Media & Partners:</strong> We share information about your use of our Site, purchases, and interaction with our ads with our advertising partners (including Facebook and Instagram) to show you relevant ads based on your browse and order activity.
                    </p>
                    <div className="text-xs">
                      <a href="https://optout.aboutads.info/" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">Digital Advertising Alliance Opt-out Portal</a>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* User Data Deletion */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600">
                  <Trash2 className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">7. User Data Deletion Instructions</h2>
                <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                  <p className="text-red-900/80 leading-relaxed mb-4">
                    If you wish to request the deletion of your personal data associated with your account on our website, please follow these steps:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-red-800/80 mb-6">
                    <li>Send an email from your <strong>registered email address</strong> (the one used to sign up or interact with our services).</li>
                    <li>Use the subject line: <strong>&quot;Request for Data Deletion&quot;</strong></li>
                    <li>Include your <strong>Full Name</strong> and any <strong>Relevant Account Details</strong> to help us verify your identity.</li>
                  </ol>
                  <a 
                    href="mailto:support@dietanic.co?subject=Request%20for%20Data%20Deletion" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-red-600 text-white font-medium rounded-xl hover:bg-red-700 transition-colors"
                  >
                    Request Data Deletion
                  </a>
                  <p className="text-xs text-red-800/60 mt-4">
                    Once we receive your request, our team will process the deletion of your data in accordance with our Privacy Policy and notify you once the process has been completed.
                  </p>
                </div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
