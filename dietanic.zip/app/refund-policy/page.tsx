'use client';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { motion } from 'motion/react';
import { ShieldCheck, RefreshCcw, XCircle, Clock, AlertCircle } from 'lucide-react';

export default function RefundPolicy() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-32 pb-20 bg-emerald-50/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-emerald-950 mb-6">Return and Refund Policy</h1>
            <p className="text-emerald-800/70 text-lg mb-8">
              Last Updated: March 7, 2026
            </p>
            <div className="h-1 w-20 bg-emerald-500 rounded-full mb-12" />
          </motion.div>
        </div>
      </div>

      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-emerald max-w-none space-y-16">
            
            {/* Replacement Terms */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
                  <RefreshCcw className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">1. Replacement Terms</h2>
                <p className="text-emerald-800/80 leading-relaxed">
                  CULTLIV DIETANIC LLP accepts replacement requests exclusively for proven product defects, damage during transit, or significant service-related issues. Please note that <strong className="text-emerald-900">refunds are not provided under any circumstances</strong>. To initiate a replacement, customers must contact us at <a href="mailto:support@dietanic.co" className="text-emerald-600 font-medium hover:underline">support@dietanic.co</a> or <a href="tel:+914448133731" className="text-emerald-600 font-medium hover:underline">+91 44 4813 3731</a> within <strong className="text-emerald-900">24 hours</strong> of delivery or service completion. You must provide the invoice, order details, and supporting evidence (such as unboxing photos or videos) to establish the defect or damage.
                </p>
              </div>
            </motion.div>

            {/* Non-Refundable Items */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600">
                  <XCircle className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">2. Non-Refundable Items & Services</h2>
                <p className="text-emerald-800/80 leading-relaxed mb-4">
                  The following items and services are strictly non-refundable:
                </p>
                <ul className="grid sm:grid-cols-2 gap-4">
                  {[
                    { title: 'Personalized Meal Plans', desc: 'Once delivered digitally, these are considered "consumed".' },
                    { title: 'Consultation Fees', desc: 'Fees for 1-on-1 sessions with nutritionists.' },
                    { title: 'Shipping & Handling', desc: 'Costs already incurred for physical dispatch.' },
                    { title: 'Platform Fees', desc: 'Processing fees from payment gateways.' }
                  ].map((item, i) => (
                    <li key={i} className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                      <h4 className="font-bold text-emerald-900 text-sm mb-1">{item.title}</h4>
                      <p className="text-xs text-emerald-800/70">{item.desc}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>

            {/* Refund Eligibility */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                  <ShieldCheck className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">3. Refund Eligibility</h2>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-bold text-emerald-900 mb-2">Full Refunds</h4>
                    <p className="text-emerald-800/80 text-sm leading-relaxed">
                      Eligible only if a cancellation request is submitted within 24 hours of the initial purchase, provided that no personalized digital plans have been generated and no physical products have been dispatched.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-emerald-900 mb-2">Pro-rated Refunds</h4>
                    <p className="text-emerald-800/80 text-sm leading-relaxed">
                      Generally not provided for active subscription terms. In exceptional cases (documented medical emergencies), a pro-rated refund may be considered at the sole discretion of management, minus administrative fees.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex gap-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
                    <p className="text-xs text-blue-800 leading-relaxed">
                      <strong>EMI Plans:</strong> Canceling the service does not cancel your debt obligation to the lending partner. You remain liable for all remaining EMIs as per your agreement with the bank.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Return Process */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600">
                  <AlertCircle className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">4. Return Process (Physical Goods)</h2>
                <div className="space-y-4">
                  <div className="p-6 bg-orange-50/50 rounded-3xl border border-orange-100">
                    <h4 className="font-bold text-orange-900 mb-2">Hygiene & Safety</h4>
                    <p className="text-orange-800/80 text-sm leading-relaxed">
                      Due to the perishable nature of our products, we do not accept returns on food items, supplements, or opened health products to ensure the safety of all our customers.
                    </p>
                  </div>
                  <p className="text-emerald-800/80 text-sm leading-relaxed">
                    <strong>Damaged or Incorrect Items:</strong> If you receive a product that is damaged or differs from your order, please notify us within 24 hours of delivery with unboxing photos or videos for a free replacement.
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Cancellation Window */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600">
                  <Clock className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-emerald-950 mb-4">5. Subscription Cancellation Window</h2>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="p-6 bg-white rounded-3xl border border-emerald-100 shadow-sm">
                    <h4 className="font-bold text-emerald-900 mb-3">Monthly</h4>
                    <p className="text-emerald-800/70 text-sm leading-relaxed">
                      Cancel any time. Requests must be submitted at least <strong>72 hours</strong> before the renewal date to avoid next cycle charges.
                    </p>
                  </div>
                  <div className="p-6 bg-white rounded-3xl border border-emerald-100 shadow-sm">
                    <h4 className="font-bold text-emerald-900 mb-3">Long-Term</h4>
                    <p className="text-emerald-800/70 text-sm leading-relaxed">
                      Cancellation stops auto-renewal for the subsequent term. The current committed term remains active until expiry.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
