'use client';

import { motion } from 'motion/react';
import { Check, HelpCircle, Minus, Share2 } from 'lucide-react';
import Image from 'next/image';

const plans = [
  {
    id: 'lite',
    name: 'Lite Plan',
    price: '3333',
    originalPrice: '3833',
    period: 'month',
    description: 'Best for weight loss, built on high-density nutrition and calorie deficits.',
    badge: '',
    image: 'https://drive.google.com/uc?export=view&id=1ta5eA007jUpqtHFIIfdwqXF2cISnrdRP',
    link: 'https://api.whatsapp.com/send/?phone=919486919916&text=Hi,%20I%20want%20to%20subscribe%20for%203333%20plan',
  },
  {
    id: 'feast',
    name: 'Feast Plan',
    price: '4444',
    originalPrice: '4944',
    period: 'month',
    description: 'Start your morning with a purpose-built breakfast designed for growth.',
    badge: 'Popular',
    image: 'https://drive.google.com/uc?export=view&id=1EnOaTkrqDqfRjCHGybMH_qAP4E6JxIb1',
    link: 'https://api.whatsapp.com/send/?phone=919486919916&text=Hi,%20I%20want%20to%20subscribe%20for%204444%20plan',
  },
  {
    id: 'gym',
    name: 'Gym Plan',
    price: '6666',
    originalPrice: '7166',
    period: 'month',
    description: 'Fuel & Recovery Pack for muscle protein synthesis & control.',
    badge: 'Pro',
    image: 'https://drive.google.com/uc?export=view&id=1R5zSiaEtXJq9GfGz8Ose85Z8r4GH-7JB',
    link: 'https://api.whatsapp.com/send/?phone=919486919916&text=Hi,%20I%20want%20to%20subscribe%20for%206666%20plan',
  },
];

const comparisonData = [
  {
    section: 'Overview',
    features: [
      { name: 'Delivery Schedule', lite: 'Morning', feast: 'Morning', gym: 'Morning', tooltip: 'All plans are delivered fresh every morning.' },
      { name: 'Monthly Units', lite: '26 Salads', feast: '26 Salads', gym: '26 Combo Packs', tooltip: 'Total number of deliveries per month.' },
      { name: 'Total Estimated Weight (At least)', lite: '~333g', feast: '~444g', gym: '~666g', tooltip: 'Minimum estimated weight per delivery.' },
      { name: 'Delivery Zone', lite: true, feast: true, gym: true, tooltip: 'Available across our Coimbatore delivery zones.' },
    ],
  },
  {
    section: 'Nutrition & Content',
    features: [
      { name: 'Fruits Variety', lite: '5 Fruits', feast: '6 Fruits', gym: '5 Fruits + 2 Veggies', tooltip: 'Variety of seasonal fruits included.' },
      { name: 'Nuts & Seeds', lite: '3 Varieties', feast: '4 Varieties', gym: '3 Varieties', tooltip: 'Premium nuts and seeds mix.' },
      { name: 'Protein Sources', lite: '1 Source', feast: '2 Sources', gym: 'Chicken / Paneer + Egg', tooltip: 'High-quality protein inclusions.' },
      { name: 'Specialized Drink', lite: 'Juice (200ml)', feast: 'Juice (200ml)', gym: 'Protein Shake (200ml)', tooltip: 'Freshly prepared daily beverage.' },
      { name: 'Recipe Rotation', lite: 'Standard', feast: 'Seasonal Specials', gym: 'High-Protein Exclusives', tooltip: 'How often and what type of new recipes are introduced.' },
    ],
  },
  {
    section: 'Value Metrics',
    features: [
      { name: 'Price per Unit', lite: '₹129', feast: '₹170', gym: '₹256', tooltip: 'Effective cost per individual delivery.' },
      { name: 'Packaging', lite: 'Regular', feast: 'Regular', gym: 'Regular', tooltip: 'Standard packaging for all meals.' },
    ],
  },
];

export default function Pricing() {
  const handleShare = (plan: typeof plans[0]) => {
    const shareData = {
      title: `Dietanic - ${plan.name}`,
      text: `Check out the ${plan.name} from Dietanic for ₹${plan.price}/${plan.period}! ${plan.description}`,
      url: `${window.location.origin}/#plans`,
    };

    if (navigator.share) {
      navigator.share(shareData).catch(err => console.error('Error sharing:', err));
    } else {
      navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
      alert('Plan details copied to clipboard!');
    }
  };

  const renderValue = (value: string | boolean) => {
    if (typeof value === 'boolean') {
      return value ? (
        <div className="flex justify-center">
          <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
            <Check className="w-4 h-4 text-emerald-600" />
          </div>
        </div>
      ) : (
        <div className="flex justify-center">
          <Minus className="w-4 h-4 text-gray-300" />
        </div>
      );
    }
    return <span className="text-sm font-medium text-emerald-900">{value}</span>;
  };

  return (
    <section id="plans" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-20">
          <h2 className="text-emerald-600 font-bold text-sm tracking-widest uppercase mb-4">Pricing</h2>
          <h3 className="text-4xl sm:text-5xl font-bold text-emerald-950 mb-6 tracking-tight">
            Compare our plans and find yours
          </h3>
          <p className="text-lg text-emerald-800/60 max-w-2xl mx-auto">
            Simple, transparent pricing designed for your health goals. 
            Choose the plan that fits your lifestyle in Coimbatore.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border-b border-gray-100 mb-12">
          {plans.map((plan) => (
            <div key={plan.id} className="p-8 flex flex-col items-center text-center border-x border-transparent first:border-l-0 last:border-r-0 md:border-gray-100">
              <div className="relative w-full aspect-[4/3] mb-8 rounded-2xl overflow-hidden border border-emerald-100 bg-emerald-50">
                <Image
                  src={plan.image}
                  alt={plan.name}
                  fill
                  className={`${plan.id === 'gym' ? 'object-contain' : 'object-cover'} hover:scale-105 transition-transform duration-500`}
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex items-center gap-2 mb-6">
                <h4 className="text-xl font-bold text-emerald-950">{plan.name}</h4>
                {plan.badge && (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-600 border border-emerald-100">
                    {plan.badge}
                  </span>
                )}
              </div>
              <div className="mb-2">
                <span className="text-lg text-emerald-800/40 line-through font-medium">₹{plan.originalPrice}</span>
              </div>
              <div className="mb-4">
                <span className="text-5xl font-bold text-emerald-950 tracking-tight">₹{plan.price}</span>
                <span className="text-emerald-600/60 font-medium ml-1">per {plan.period}</span>
              </div>
              <div className="mb-6">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-700 border border-emerald-200 animate-pulse">
                  <Check className="w-3 h-3 mr-1" /> Coupon Pre-applied
                </span>
              </div>
              <p className="text-sm text-emerald-800/60 mb-8 min-h-[40px]">
                {plan.description}
              </p>
              <div className="w-full space-y-3">
                <a
                  href={plan.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-3 px-6 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg font-bold transition-all shadow-md shadow-emerald-500/20"
                >
                  Get started
                </a>
                <button
                  onClick={() => handleShare(plan)}
                  className="w-full py-3 px-6 bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg font-bold transition-all flex items-center justify-center gap-2"
                >
                  Share Details
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="hidden md:block overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="py-6 px-4 text-left w-1/4"></th>
                {plans.map((plan) => (
                  <th key={plan.id} className="py-6 px-4 text-center w-1/4">
                    <span className="text-sm font-bold text-emerald-950 uppercase tracking-widest">{plan.name}</span>
                  </th>
                ))}
              </tr>
            </thead>
            {comparisonData.map((section) => (
              <tbody key={section.section}>
                <tr>
                  <td colSpan={4} className="py-8 px-4">
                    <h5 className="text-sm font-bold text-emerald-600 uppercase tracking-widest">{section.section}</h5>
                  </td>
                </tr>
                {section.features.map((feature, idx) => (
                  <tr key={idx} className="group hover:bg-emerald-50/30 transition-colors">
                    <td className="py-4 px-4 border-b border-gray-50">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-emerald-900/80">{feature.name}</span>
                        <span title={feature.tooltip}>
                          <HelpCircle className="w-3.5 h-3.5 text-emerald-300 cursor-help" />
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center border-b border-gray-50">
                      {renderValue(feature.lite)}
                    </td>
                    <td className="py-4 px-4 text-center border-b border-gray-50">
                      {renderValue(feature.feast)}
                    </td>
                    <td className="py-4 px-4 text-center border-b border-gray-50">
                      {renderValue(feature.gym)}
                    </td>
                  </tr>
                ))}
              </tbody>
            ))}
          </table>
        </div>

        {/* Mobile Comparison (Simplified) */}
        <div className="md:hidden space-y-12 mt-12">
          {plans.map((plan) => (
            <div key={plan.id} className="bg-emerald-50/30 rounded-2xl p-6 border border-emerald-100">
              <h4 className="text-xl font-bold text-emerald-950 mb-6 text-center">{plan.name} Features</h4>
              <div className="space-y-4">
                {comparisonData.flatMap(s => s.features).map((f, i) => (
                  <div key={i} className="flex justify-between items-center py-2 border-b border-emerald-100/50 last:border-0">
                    <span className="text-sm text-emerald-800/60">{f.name}</span>
                    <span className="text-sm font-bold text-emerald-950">
                      {/* @ts-ignore */}
                      {typeof f[plan.id] === 'boolean' ? (f[plan.id] ? 'Yes' : 'No') : f[plan.id]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
