'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ClipboardList, CheckCircle2, ArrowRight, RefreshCcw, Sparkles } from 'lucide-react';

const questions = [
  {
    id: 'goal',
    question: 'What is your primary health goal?',
    options: [
      { label: 'Weight Loss', value: 'weight-loss', icon: '🔥' },
      { label: 'Muscle Gain', value: 'muscle-gain', icon: '💪' },
      { label: 'General Health', value: 'health', icon: '🥗' },
    ],
  },
  {
    id: 'preference',
    question: 'What is your dietary preference?',
    options: [
      { label: 'Vegetarian', value: 'veg', icon: '🥬' },
      { label: 'Non-Vegetarian', value: 'non-veg', icon: '🍗' },
      { label: 'Vegan', value: 'vegan', icon: '🌱' },
    ],
  },
  {
    id: 'activity',
    question: 'How active is your lifestyle?',
    options: [
      { label: 'Sedentary', value: 'low', icon: '🪑' },
      { label: 'Moderate', value: 'medium', icon: '🚶' },
      { label: 'Very Active', value: 'high', icon: '🏃' },
    ],
  },
];

export default function MealQuiz() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (value: string) => {
    const newAnswers = { ...answers, [questions[step].id]: value };
    setAnswers(newAnswers);

    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      setShowResult(true);
    }
  };

  const getRecommendation = () => {
    const { goal, preference, activity } = answers;

    if (goal === 'muscle-gain' || activity === 'high') {
      return {
        plan: 'Gym Plan',
        reason: 'You need high protein and calorie-dense meals to support muscle synthesis and high energy demands.',
        link: 'https://api.whatsapp.com/send/?phone=919486919916&text=Hi,%20I%20completed%20the%20quiz%20and%20got%20the%20Gym%20Plan%20recommendation!',
      };
    }

    if (goal === 'weight-loss') {
      return {
        plan: 'Lite Plan',
        reason: 'Our Lite Plan is perfectly balanced for calorie deficits while ensuring high-density nutrition.',
        link: 'https://api.whatsapp.com/send/?phone=919486919916&text=Hi,%20I%20completed%20the%20quiz%20and%20got%20the%20Lite%20Plan%20recommendation!',
      };
    }

    return {
      plan: 'Feast Plan',
      reason: 'The Feast Plan provides a balanced mix of nutrients ideal for maintaining a healthy lifestyle and steady energy.',
      link: 'https://api.whatsapp.com/send/?phone=919486919916&text=Hi,%20I%20completed%20the%20quiz%20and%20got%20the%20Feast%20Plan%20recommendation!',
    };
  };

  const reset = () => {
    setStep(0);
    setAnswers({});
    setShowResult(false);
  };

  return (
    <div className="bg-white rounded-3xl p-8 border border-emerald-100 shadow-xl h-full flex flex-col">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
          <ClipboardList className="w-6 h-6 text-emerald-600" />
        </div>
        <h3 className="text-2xl font-bold text-emerald-950">Meal Planning Quiz</h3>
      </div>

      <p className="text-emerald-800/60 text-sm mb-8 leading-relaxed">
        Answer 3 quick questions to discover the perfect Dietanic subscription plan for your body and lifestyle.
      </p>

      <div className="flex-1">
        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-bold text-emerald-500 uppercase tracking-widest">Question {step + 1} of {questions.length}</span>
                <div className="flex gap-1">
                  {questions.map((_, i) => (
                    <div key={i} className={`h-1 w-6 rounded-full transition-all ${i <= step ? 'bg-emerald-500' : 'bg-emerald-100'}`} />
                  ))}
                </div>
              </div>

              <h4 className="text-xl font-bold text-emerald-950 leading-tight">
                {questions[step].question}
              </h4>

              <div className="grid grid-cols-1 gap-3">
                {questions[step].options.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleSelect(option.value)}
                    className="flex items-center gap-4 p-4 rounded-2xl border border-emerald-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all text-left group"
                  >
                    <span className="text-2xl">{option.icon}</span>
                    <span className="font-bold text-emerald-900 group-hover:text-emerald-700">{option.label}</span>
                    <ArrowRight className="w-4 h-4 ml-auto text-emerald-200 group-hover:text-emerald-500 group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-6"
            >
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-emerald-600" />
              </div>
              
              <div>
                <h4 className="text-sm font-bold text-emerald-500 uppercase tracking-widest mb-2">Your Recommendation</h4>
                <p className="text-3xl font-black text-emerald-950 mb-4">{getRecommendation().plan}</p>
                <p className="text-emerald-800/70 text-sm leading-relaxed mb-8 px-4">
                  {getRecommendation().reason}
                </p>
              </div>

              <div className="space-y-3">
                <a
                  href={getRecommendation().link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-emerald-500/20"
                >
                  Start with this Plan
                </a>
                <button
                  onClick={reset}
                  className="flex items-center justify-center gap-2 w-full py-3 text-emerald-600 font-bold hover:text-emerald-700 transition-all"
                >
                  <RefreshCcw className="w-4 h-4" />
                  Retake Quiz
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
