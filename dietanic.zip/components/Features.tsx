'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Apple, Dumbbell, Clock, Scale, ChevronLeft, ChevronRight } from 'lucide-react';

const features = [
  {
    title: 'Clean Eater',
    description: 'We deliver fruit salads as breakfast meals to our customers who are health conscious and planning consistent eating habits.',
    icon: Apple,
    color: 'bg-emerald-100 text-emerald-600',
  },
  {
    title: 'Fitness Enthusiast',
    description: 'We deliver meals for gym-goers who specifically love working out to ensure a motivated, disciplined routine and lifestyle.',
    icon: Dumbbell,
    color: 'bg-orange-100 text-orange-600',
  },
  {
    title: 'Saves Time',
    description: 'Lifestyle Integration. We dive deep into your unique physiology, habits, and goals to co-create a sustainable roadmap.',
    icon: Clock,
    color: 'bg-blue-100 text-blue-600',
  },
  {
    title: 'Portion Control',
    description: 'Quick check-ins and real-time adjustments happen via our platform. We bring the expertise to your pocket.',
    icon: Scale,
    color: 'bg-purple-100 text-purple-600',
  },
];

export default function Features() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerView, setItemsPerView] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setItemsPerView(3);
      } else if (window.innerWidth >= 768) {
        setItemsPerView(2);
      } else {
        setItemsPerView(1);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const next = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % (features.length - itemsPerView + 1));
  }, [itemsPerView]);

  const prev = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + (features.length - itemsPerView + 1)) % (features.length - itemsPerView + 1));
  }, [itemsPerView]);

  return (
    <section id="how-it-works" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-emerald-600 font-semibold tracking-wide uppercase text-sm mb-3">How Our Healthy Meal Subscription Works</h2>
          <p className="mt-2 text-4xl font-extrabold text-emerald-950 tracking-tight sm:text-5xl">
            Designed for the modern, health-conscious individual in Coimbatore.
          </p>
        </div>

        <div className="relative group">
          <div className="overflow-hidden">
            <motion.div
              animate={{ x: `-${currentIndex * (100 / itemsPerView)}%` }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="flex gap-6"
            >
              {features.map((feature, i) => (
                <div
                  key={feature.title}
                  className="flex-shrink-0"
                  style={{ width: `calc((100% - ${(itemsPerView - 1) * 24}px) / ${itemsPerView})` }}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.6, delay: i * 0.1, ease: 'easeOut' }}
                    className="h-full p-8 bg-emerald-50/50 rounded-3xl border border-emerald-100 hover:shadow-xl hover:bg-white transition-all duration-300 group/card"
                  >
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${feature.color} group-hover/card:scale-110 transition-transform duration-300`}>
                      <feature.icon className="w-7 h-7" />
                    </div>
                    <h3 className="text-xl font-bold text-emerald-950 mb-4">{feature.title}</h3>
                    <p className="text-emerald-800/70 leading-relaxed">
                      {feature.description}
                    </p>
                  </motion.div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 lg:-translate-x-12 w-12 h-12 bg-white rounded-full shadow-lg border border-emerald-100 flex items-center justify-center text-emerald-600 hover:bg-emerald-50 transition-colors z-10 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 lg:group-hover:-translate-x-6"
            aria-label="Previous slide"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 lg:translate-x-12 w-12 h-12 bg-white rounded-full shadow-lg border border-emerald-100 flex items-center justify-center text-emerald-600 hover:bg-emerald-50 transition-colors z-10 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 lg:group-hover:translate-x-6"
            aria-label="Next slide"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-12">
            {Array.from({ length: features.length - itemsPerView + 1 }).map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                  currentIndex === i ? 'bg-emerald-500 w-8' : 'bg-emerald-200 hover:bg-emerald-300'
                }`}
                aria-label={`Go to slide ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
