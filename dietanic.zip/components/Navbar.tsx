'use client';

import Link from 'next/link';
import Image from 'next/image';
import Search from './Search';

export default function Navbar() {
  return (
    <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center gap-8">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <Image
                  src="https://i.ibb.co/pjPBL2KJ/logo-dietanic.png"
                  alt="Dietanic Logo"
                  width={140}
                  height={40}
                  className="h-10 w-auto"
                />
              </Link>
            </div>
            <div className="hidden lg:block">
              <Search />
            </div>
          </div>
          
          <div className="flex items-center gap-4 md:gap-8">
            <div className="lg:hidden">
              <Search />
            </div>
            <div className="hidden md:flex items-center gap-8">
              <Link href="#plans" className="text-sm font-bold text-emerald-900 hover:text-emerald-600 transition-colors">Plans</Link>
              <a 
                href="https://api.whatsapp.com/send/?phone=919486919916&text=Hi" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full text-sm font-bold transition-all shadow-md shadow-emerald-500/20"
              >
                Contact Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
