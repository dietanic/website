'use client';

import { useState, useEffect, useRef } from 'react';
import { Search as SearchIcon, X, ArrowRight, FileText, HelpCircle, Package, Salad } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';

interface SearchItem {
  id: string;
  title: string;
  description: string;
  category: 'Plans' | 'FAQ' | 'Policy' | 'Menu' | 'Products';
  link: string;
}

const searchData: SearchItem[] = [
  // Plans
  { id: 'lite-plan', title: 'Lite Plan', description: 'Best for weight loss, built on high-density nutrition and deficits.', category: 'Plans', link: '#plans' },
  { id: 'feast-plan', title: 'Feast Plan', description: 'Start your morning with a purpose-built breakfast designed for growth.', category: 'Plans', link: '#plans' },
  { id: 'gym-plan', title: 'Gym Plan', description: 'Fuel & Recovery Pack for muscle protein synthesis & control.', category: 'Plans', link: '#plans' },
  
  // Products/Menu
  { id: 'fruit-salad', title: 'Fresh Fruit Salad', description: 'Daily fruit bowls made with fresh seasonal fruits.', category: 'Products', link: '#hero' },
  { id: 'healthy-meals', title: 'Healthy Meal Delivery', description: 'Nutritious salads delivered fresh to your doorstep.', category: 'Products', link: '#hero' },
  { id: 'health-tools', title: 'Health Tools', description: 'BMI Calculator and Meal Planning Quiz.', category: 'Menu', link: '#tools' },
  
  // FAQ
  { id: 'faq-location', title: 'Delivery Location', description: 'Where do we deliver in Coimbatore?', category: 'FAQ', link: '#faq' },
  { id: 'faq-charges', title: 'Delivery Charges', description: 'Information about shipping and delivery costs.', category: 'FAQ', link: '#faq' },
  { id: 'faq-hours', title: 'Delivery Hours', description: 'What time do we deliver?', category: 'FAQ', link: '#faq' },
  { id: 'faq-payments', title: 'Payment Methods', description: 'Accepted payment methods including UPI and Cards.', category: 'FAQ', link: '#faq' },
  
  // Policies
  { id: 'policy-terms', title: 'Terms of Service', description: 'Our terms and conditions for using the service.', category: 'Policy', link: '/terms' },
  { id: 'policy-privacy', title: 'Privacy Policy', description: 'How we handle your personal data.', category: 'Policy', link: '/privacy-policy' },
  { id: 'policy-medical', title: 'Medical Disclaimer', description: 'Important health and medical information.', category: 'Policy', link: '/medical-disclaimer' },
  { id: 'policy-refund', title: 'Refund Policy', description: 'Our policy on refunds and cancellations.', category: 'Policy', link: '/refund-policy' },
];

export default function Search() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const results = query.trim() === '' 
    ? [] 
    : searchData.filter(item => 
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase())
      );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(true);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isOpen]);

  const handleClose = () => {
    setIsOpen(false);
    setQuery('');
  };

  const getIcon = (category: string) => {
    switch (category) {
      case 'Plans': return <Package className="w-4 h-4" />;
      case 'FAQ': return <HelpCircle className="w-4 h-4" />;
      case 'Policy': return <FileText className="w-4 h-4" />;
      case 'Products': return <Salad className="w-4 h-4" />;
      default: return <SearchIcon className="w-4 h-4" />;
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 rounded-lg text-emerald-900/50 text-sm transition-all group"
      >
        <SearchIcon className="w-4 h-4 text-emerald-600" />
        <span className="hidden sm:inline">Search...</span>
        <kbd className="hidden sm:flex items-center gap-1 px-1.5 py-0.5 bg-white border border-emerald-200 rounded text-[10px] font-bold text-emerald-400">
          <span className="text-xs">⌘</span>K
        </kbd>
      </button>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[100] flex items-start justify-center pt-20 px-4 sm:pt-32">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleClose}
              className="absolute inset-0 bg-emerald-950/20 backdrop-blur-sm"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-emerald-100 overflow-hidden"
            >
              <div className="flex items-center px-4 border-b border-emerald-50">
                <SearchIcon className="w-5 h-5 text-emerald-400" />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search for plans, salads, FAQ..."
                  className="flex-1 px-4 py-5 bg-transparent outline-none text-emerald-950 placeholder:text-emerald-300"
                />
                <button
                  onClick={handleClose}
                  className="p-2 hover:bg-emerald-50 rounded-lg text-emerald-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="max-h-[60vh] overflow-y-auto p-2">
                {query.trim() === '' ? (
                  <div className="p-8 text-center">
                    <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <SearchIcon className="w-6 h-6 text-emerald-200" />
                    </div>
                    <p className="text-emerald-950 font-bold mb-1">Search Dietanic</p>
                    <p className="text-sm text-emerald-800/50">Find plans, products, policies and more.</p>
                  </div>
                ) : results.length > 0 ? (
                  <div className="space-y-1">
                    {results.map((item) => (
                      <Link
                        key={item.id}
                        href={item.link}
                        onClick={handleClose}
                        className="flex items-start gap-4 p-4 rounded-xl hover:bg-emerald-50 transition-all group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                          {getIcon(item.category)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="font-bold text-emerald-950 truncate">{item.title}</span>
                            <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-[10px] font-bold text-emerald-600 uppercase tracking-wider">
                              {item.category}
                            </span>
                          </div>
                          <p className="text-sm text-emerald-800/60 line-clamp-1">{item.description}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-emerald-200 group-hover:text-emerald-500 group-hover:translate-x-1 transition-all self-center" />
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <p className="text-emerald-950 font-bold mb-1">No results found</p>
                    <p className="text-sm text-emerald-800/50">Try searching for something else.</p>
                  </div>
                )}
              </div>

              <div className="px-4 py-3 bg-emerald-50/50 border-t border-emerald-50 flex items-center justify-between text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
                <div className="flex gap-4">
                  <span className="flex items-center gap-1"><kbd className="px-1 bg-white border border-emerald-200 rounded">ESC</kbd> to close</span>
                  <span className="flex items-center gap-1"><kbd className="px-1 bg-white border border-emerald-200 rounded">↵</kbd> to select</span>
                </div>
                <span>{results.length} results</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
