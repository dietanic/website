'use client';

import BMICalculator from './BMICalculator';
import MealQuiz from './MealQuiz';

export default function InteractiveTools() {
  return (
    <section id="tools" className="py-24 bg-emerald-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-emerald-600 font-bold text-sm tracking-widest uppercase mb-4">Health Tools</h2>
          <h3 className="text-4xl sm:text-5xl font-bold text-emerald-950 mb-6 tracking-tight">
            Personalize your health journey
          </h3>
          <p className="text-lg text-emerald-800/60 max-w-2xl mx-auto">
            Use our interactive tools to understand your body better and find the perfect meal plan tailored to your needs.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <BMICalculator />
          <MealQuiz />
        </div>
      </div>
    </section>
  );
}
