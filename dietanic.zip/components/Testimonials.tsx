'use client';

import { motion } from 'motion/react';
import { Quote, Star } from 'lucide-react';
import Image from 'next/image';

const testimonials = [
  {
    name: 'Priya Sharma',
    role: 'Fitness Enthusiast',
    content: 'Dietanic has completely changed my morning routine. The salads are incredibly fresh and the variety of fruits and nuts keeps it exciting every day!',
    avatar: 'https://picsum.photos/seed/priya/100/100',
    rating: 5,
  },
  {
    name: 'Arjun Reddy',
    role: 'Software Engineer',
    content: 'As someone with a busy schedule, having a healthy, pre-packed breakfast delivered is a lifesaver. The Feast Plan is perfect for my energy needs.',
    avatar: 'https://picsum.photos/seed/arjun/100/100',
    rating: 5,
  },
  {
    name: 'Meera Krishnan',
    role: 'Yoga Instructor',
    content: 'I love the quality of the ingredients. You can tell everything is carefully selected. The Gym Plan helps me stay on track with my protein goals.',
    avatar: 'https://picsum.photos/seed/meera/100/100',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-emerald-600 font-semibold tracking-wide uppercase text-sm mb-3">Testimonials</h2>
          <p className="mt-2 text-4xl font-extrabold text-emerald-950 tracking-tight sm:text-5xl">
            What our cultivated community says
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: index * 0.1, ease: 'easeOut' }}
              className="relative bg-emerald-50/50 rounded-3xl p-6 sm:p-8 border border-emerald-100 flex flex-col"
            >
              <div className="absolute -top-4 -left-4 w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-200">
                <Quote className="w-6 h-6" />
              </div>

              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              <p className="text-emerald-900/80 leading-relaxed mb-8 italic text-lg">
                &ldquo;{testimonial.content}&rdquo;
              </p>

              <div className="mt-auto flex items-center gap-4">
                <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-emerald-200">
                  <Image
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="font-bold text-emerald-950">{testimonial.name}</h4>
                  <p className="text-emerald-600 text-sm font-medium">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
