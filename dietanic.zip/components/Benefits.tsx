'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { RefreshCw, Activity, ShieldCheck, LeafyGreen, ChevronLeft, ChevronRight } from 'lucide-react';

const benefits = [
  {
    title: 'Results That Last',
    description: 'Achieve standard weight management with our diet. We include personalized nutrition to lock in long-term success.',
    icon: RefreshCw,
  },
  {
    title: 'Muscle Strength',
    description: 'Our Dietanic™ protocol pairs muscle gain with strength training to prevent muscle loss and support metabolism.',
    icon: Activity,
  },
  {
    title: 'Side Effect Defense',
    description: 'We tailor your nutrition and dosing carefully to keep you energized, comfortable, and in full control.',
    icon: ShieldCheck,
  },
  {
    title: 'Sustainable',
    description: 'We help you build habits that stick — so your progress continues naturally, even without medication.',
    icon: LeafyGreen,
  },
];

export default function Benefits() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % benefits.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + benefits.length) % benefits.length);
  };

  return (
    <section id="benefits" className="py-24 bg-white text-emerald-950 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-emerald-600 font-semibold tracking-wide uppercase text-sm mb-3">Benefits of Our Fresh Salad Diet</h2>
            <p className="mt-2 text-4xl font-extrabold tracking-tight sm:text-5xl mb-8 text-emerald-950">
              Why our plant-based fruit and salad bowls work better 🍃
            </p>
            <p className="text-emerald-800/70 text-lg leading-relaxed mb-10 max-w-xl">
              Know about your Current Plans, Past Quotes & Invoices, Wallet Balance, Refunds and Payment Methods in our One Subscription Portal.
            </p>
            
            <a
              href="https://one.dietanic.co"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full font-semibold text-lg transition-all shadow-lg hover:shadow-emerald-500/50"
            >
              Access Portal ↗
            </a>
          </motion.div>

          <div className="relative w-full max-w-lg mx-auto lg:mx-0">
            <div className="relative h-[320px] sm:h-[280px] w-full">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentIndex}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0 bg-emerald-50/80 backdrop-blur-sm p-8 sm:p-10 rounded-3xl border border-emerald-100 flex flex-col justify-center shadow-sm"
                >
                  <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mb-6 text-emerald-600">
                    {(() => {
                      const Icon = benefits[currentIndex].icon;
                      return <Icon className="w-7 h-7" />;
                    })()}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-emerald-950">{benefits[currentIndex].title}</h3>
                  <p className="text-emerald-800/70 leading-relaxed text-base">
                    {benefits[currentIndex].description}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="flex items-center justify-center gap-6 mt-8">
              <button
                onClick={prevSlide}
                className="w-12 h-12 rounded-full border border-emerald-200 flex items-center justify-center text-emerald-600 hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                aria-label="Previous benefit"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <div className="flex gap-3">
                {benefits.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`w-2.5 h-2.5 rounded-full transition-colors ${
                      idx === currentIndex ? 'bg-emerald-500' : 'bg-emerald-200 hover:bg-emerald-300'
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>
              <button
                onClick={nextSlide}
                className="w-12 h-12 rounded-full border border-emerald-200 flex items-center justify-center text-emerald-600 hover:bg-emerald-50 hover:border-emerald-300 transition-colors"
                aria-label="Next benefit"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
