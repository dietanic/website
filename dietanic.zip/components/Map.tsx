'use client';

import { useEffect } from 'react';
import { MapContainer, TileLayer, Circle, Marker, Popup, Tooltip } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icon in Next.js
const icon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

export default function DeliveryMap({ radiusInKm = 8 }: { radiusInKm?: number }) {
  const center: [number, number] = [11.0168, 76.9659];
  const radiusInMeters = radiusInKm * 1000;

  return (
    <div className="w-full h-[300px] sm:h-[400px] rounded-2xl overflow-hidden border border-emerald-100 shadow-lg z-0 relative">
      <MapContainer 
        center={center} 
        zoom={12} 
        scrollWheelZoom={false} 
        style={{ height: '100%', width: '100%', zIndex: 0 }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Circle 
          center={center} 
          radius={radiusInMeters}
          pathOptions={{ 
            color: '#10b981', 
            fillColor: '#10b981', 
            fillOpacity: 0.2,
            weight: 2
          }}
        />
        <Marker position={center} icon={icon}>
          <Popup>
            <div className="text-center">
              <strong>Delivery Hub</strong><br />
              <span className="text-emerald-600 text-xs">{radiusInKm}km Delivery Radius</span>
            </div>
          </Popup>
          <Tooltip permanent direction="top" offset={[0, -40]} className="font-bold text-emerald-800 bg-white border-emerald-200 shadow-md">
            {radiusInKm} km Delivery Radius
          </Tooltip>
        </Marker>
      </MapContainer>
    </div>
  );
}
