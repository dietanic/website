'use client';

import dynamic from 'next/dynamic';
import { MapPin, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

const Map = dynamic(() => import('./Map'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[300px] sm:h-[400px] rounded-2xl bg-emerald-50/50 border border-emerald-100 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Animated Grid Background */}
      <div 
        className="absolute inset-0 opacity-10 pointer-events-none" 
        style={{ backgroundImage: 'radial-gradient(#10b981 1px, transparent 1px)', backgroundSize: '24px 24px' }} 
      />
      
      <motion.div 
        animate={{ 
          y: [0, -10, 0],
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="relative mb-4"
      >
        <div className="absolute inset-0 bg-emerald-400 blur-2xl opacity-30 rounded-full" />
        <MapPin className="w-12 h-12 text-emerald-500 relative z-10" />
      </motion.div>
      
      <div className="flex items-center gap-2 text-emerald-700 font-bold tracking-tight">
        <Loader2 className="w-5 h-5 animate-spin text-emerald-500" />
        <span>Loading Delivery Map...</span>
      </div>
      
      <p className="text-emerald-800/50 text-xs mt-2 font-medium">Pinpointing our Coimbatore hub</p>
    </div>
  ),
});

export default function DeliveryZone() {
  return (
    <section id="delivery" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-emerald-600 font-semibold tracking-wide uppercase text-sm mb-3">Our Salad Delivery Areas in Coimbatore</h2>
          <p className="mt-2 text-4xl font-extrabold text-emerald-950 tracking-tight sm:text-5xl">
            Delivery Zones
          </p>
          <p className="mt-4 text-emerald-800/70 text-lg">
            Check if your location falls within our green service area for fresh fruit delivery in Coimbatore.
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative z-0">
          <Map radiusInKm={8} />
          
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-6 text-sm font-medium text-emerald-800/70">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-emerald-500/20 border-2 border-emerald-500"></div>
              <span>8km Service Radius</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-500/20 border-2 border-blue-500"></div>
              <span>Delivery Hub</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
