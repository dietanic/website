'use client';

import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import Image from 'next/image';
import { BadgeGroup } from "@/components/base/badges/badge-groups";

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-emerald-50/50">
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-7xl mx-auto opacity-30 pointer-events-none">
          <div className="absolute -top-48 -left-48 w-96 h-96 bg-emerald-300 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob" />
          <div className="absolute top-0 -right-48 w-96 h-96 bg-yellow-300 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000" />
          <div className="absolute -bottom-48 left-48 w-96 h-96 bg-orange-300 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center lg:text-left"
          >
            <div className="flex flex-col items-center lg:items-start gap-4 mb-6">
              <BadgeGroup addonText="Premium" color="brand" theme="modern" align="leading" size="lg">
                Subscription
              </BadgeGroup>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-sans font-bold text-emerald-950 tracking-tight leading-[1.1] mb-6">
              Fresh Fruit Salad & <span className="text-emerald-500">Healthy Meal Delivery</span> in Coimbatore
            </h1>
            <p className="text-lg lg:text-xl text-emerald-800/80 mb-8 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Elevate your health with daily fruit bowls and nutritious salads. Made with fresh fruits, veggies, and nuts for the modern, health-conscious individual.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 mb-10">
              <a
                href="#plans"
                className="w-full sm:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full font-semibold text-lg transition-all shadow-xl shadow-emerald-500/20 hover:shadow-emerald-500/40 transform hover:-translate-y-1 flex items-center justify-center gap-2 group"
              >
                View Meal Plans
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="https://api.whatsapp.com/send/?phone=919486919916&text=Hi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-full font-semibold text-lg transition-all shadow-sm flex items-center justify-center gap-2"
              >
                Chat with us
              </a>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-6 text-sm font-medium text-emerald-800/70">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <span>Free Morning Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <span>Fresh Ingredients</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative lg:h-[600px] flex items-center justify-center"
          >
            <div className="relative w-full max-w-lg aspect-square">
              <div className="absolute inset-0 bg-gradient-to-tr from-emerald-400 to-yellow-300 rounded-full blur-3xl opacity-20 animate-pulse" />
              <Image
                src="https://i.ibb.co/GfJryS5t/unnamed.png"
                alt="Fresh Fruit and Salad Bowl"
                fill
                className="object-cover rounded-[3rem] shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-700 ease-out border-8 border-white"
                referrerPolicy="no-referrer"
                priority
              />
              
              {/* Social Proof Badge */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="absolute -bottom-6 -left-6 bg-white p-4 rounded-2xl shadow-xl border border-emerald-100 flex items-center gap-4"
              >
                <div className="flex -space-x-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="relative w-10 h-10 rounded-full border-2 border-white overflow-hidden bg-emerald-100">
                      <Image
                        src={`https://picsum.photos/seed/user${i}/100/100`}
                        alt={`User ${i}`}
                        fill
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-sm font-bold text-emerald-950">62+</p>
                  <p className="text-xs text-emerald-600 font-medium leading-tight">People have already<br />optimized their wellness</p>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
