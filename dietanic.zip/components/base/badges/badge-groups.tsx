'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface BadgeGroupProps {
  children: React.ReactNode;
  addonText?: string;
  color?: 'brand' | 'gray' | 'error' | 'warning' | 'success';
  theme?: 'modern' | 'classic';
  align?: 'leading' | 'center';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const BadgeGroup = ({
  children,
  addonText,
  color = 'brand',
  theme = 'modern',
  align = 'leading',
  size = 'md',
  className,
}: BadgeGroupProps) => {
  const colorStyles = {
    brand: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    gray: 'bg-gray-50 text-gray-700 border-gray-200',
    error: 'bg-red-50 text-red-700 border-red-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    success: 'bg-green-50 text-green-700 border-green-200',
  };

  const addonStyles = {
    brand: 'bg-emerald-500 text-white',
    gray: 'bg-gray-500 text-white',
    error: 'bg-red-500 text-white',
    warning: 'bg-amber-500 text-white',
    success: 'bg-green-500 text-white',
  };

  const sizeStyles = {
    sm: 'text-xs py-0.5 px-2',
    md: 'text-sm py-1 px-3',
    lg: 'text-base py-1.5 px-4',
  };

  const addonSizeStyles = {
    sm: 'px-1.5 py-0.5 text-[10px]',
    md: 'px-2 py-0.5 text-[11px]',
    lg: 'px-2.5 py-1 text-[12px]',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center rounded-full border font-medium transition-all',
        colorStyles[color],
        sizeStyles[size],
        align === 'center' ? 'mx-auto' : '',
        className
      )}
    >
      {addonText && (
        <span
          className={cn(
            'mr-2 rounded-full font-bold uppercase tracking-wider',
            addonStyles[color],
            addonSizeStyles[size]
          )}
        >
          {addonText}
        </span>
      )}
      <span className="flex items-center gap-1.5">{children}</span>
    </div>
  );
};
