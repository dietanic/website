'use client';

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const categories = [
  {
    id: 'fruits',
    name: 'Fruits',
    description: 'Hand-picked seasonal fruits, washed and cut fresh every morning. We prioritize local sourcing and peak ripeness.',
    items: [
      { name: 'Pomegranate', weight: '(~40 - 60g*)' },
      { name: 'Kiwi', weight: '(~40 - 60g*)' },
      { name: 'Green Apple', weight: '(~40 - 60g*)' },
      { name: 'Red Grapes', weight: '(~40 - 60g*)' },
      { name: 'Papaya', weight: '(~40 - 60g*)' },
      { name: 'Pineapple', weight: '(~40 - 60g*)' },
      { name: 'Dragon Fruit', weight: '(~40 - 60g*)' },
      { name: 'Muskmelon', weight: '(~40 - 60g*)' },
    ]
  },
  {
    id: 'veggies',
    name: 'Veggies',
    description: 'Crisp, garden-fresh vegetables that provide essential fiber and micronutrients for a balanced meal.',
    items: [
      { name: 'Iceberg Lettuce', weight: '40g' },
      { name: 'English Cucumber', weight: '60g' },
      { name: 'Cherry Tomatoes', weight: '30g' },
      { name: 'Bell Peppers', weight: '50g' },
      { name: 'Sweet Corn', weight: '45g' },
      { name: 'Purple Cabbage', weight: '35g' },
      { name: 'Carrot Juliennes', weight: '40g' },
      { name: 'Broccoli', weight: '55g' },
    ]
  },
  {
    id: 'protein',
    name: 'Protein Sources',
    description: 'High-quality protein inclusions to support muscle recovery and keep you satiated throughout the day.',
    items: [
      { name: 'Grilled Chicken', weight: '100g' },
      { name: 'Fresh Paneer', weight: '80g' },
      { name: 'Boiled Egg', weight: '2 Units' },
      { name: 'Organic Tofu', weight: '90g' },
      { name: 'Sprouted Moong', weight: '60g' },
      { name: 'Chickpeas', weight: '70g' },
      { name: 'Soya Chunks', weight: '50g' },
      { name: 'Peanut Butter', weight: '30g' },
    ]
  },
  {
    id: 'drinks',
    name: 'Drinks',
    description: 'Cold-pressed juices and protein-rich beverages to complement your meal and boost hydration.',
    items: [
      { name: 'Orange Juice', weight: '200ml' },
      { name: 'Watermelon Juice', weight: '200ml' },
      { name: 'Whey Protein', weight: '250ml' },
      { name: 'Detox Water', weight: '300ml' },
      { name: 'Coconut Water', weight: '200ml' },
      { name: 'ABC Juice', weight: '200ml' },
      { name: 'Buttermilk', weight: '250ml' },
      { name: 'Lemonade', weight: '200ml' },
    ]
  },
  {
    id: 'nuts',
    name: 'Nuts & Seeds',
    description: 'Premium crunch and healthy fats. We use a mix of roasted nuts and organic seeds for texture and nutrition.',
    items: [
      { name: 'California Walnuts', weight: '15g' },
      { name: 'Roasted Almonds', weight: '20g' },
      { name: 'Chia Seeds', weight: '10g' },
      { name: 'Pumpkin Seeds', weight: '12g' },
      { name: 'Flax Seeds', weight: '8g' },
      { name: 'Sunflower Seeds', weight: '10g' },
      { name: 'Cashews', weight: '15g' },
      { name: 'Pistachios', weight: '12g' },
    ]
  }
];

export default function Ingredients() {
  const [activeCategory, setActiveCategory] = useState(categories[0]);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="py-24 bg-emerald-50/30 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-emerald-600 font-bold text-sm tracking-widest uppercase mb-4">Our Ingredients</h2>
          <h3 className="text-3xl sm:text-4xl font-bold text-emerald-950 mb-6 tracking-tight">
            Cultivated with care, served with pride
          </h3>
        </div>

        {/* Pill Navigation */}
        <div className="relative max-w-2xl mx-auto mb-16">
          <div className="flex items-center bg-gray-200/50 backdrop-blur-sm rounded-full p-1.5 shadow-inner">
            <button 
              onClick={() => handleScroll('left')}
              className="p-2 hover:bg-white/50 rounded-full transition-colors text-gray-500"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div 
              ref={scrollRef}
              className="flex-1 flex overflow-x-auto scrollbar-hide gap-2 px-2 no-scrollbar"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category)}
                  className={`relative px-6 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap z-10 ${
                    activeCategory.id === category.id 
                      ? 'text-white' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {activeCategory.id === category.id && (
                    <motion.div
                      layoutId="active-pill"
                      className="absolute inset-0 bg-[#1a1a1a] rounded-full -z-10"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  {category.name}
                </button>
              ))}
            </div>

            <button 
              onClick={() => handleScroll('right')}
              className="p-2 hover:bg-white/50 rounded-full transition-colors text-gray-500"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Section */}
        <div className="max-w-5xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="text-center"
            >
              <div className="mb-12">
                <p className="text-xl text-emerald-900/80 leading-relaxed max-w-2xl mx-auto">
                  <span className="font-bold text-emerald-950">{activeCategory.name}.</span> {activeCategory.description}
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {activeCategory.items.map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className="group relative bg-white border border-emerald-100/50 rounded-2xl p-6 hover:shadow-xl hover:shadow-emerald-500/5 hover:-translate-y-1 transition-all duration-300 flex flex-col items-center justify-center text-center"
                  >
                    <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500/0 group-hover:bg-emerald-500/100 transition-all duration-500 rounded-t-2xl" />
                    <h4 className="font-bold text-emerald-950 mb-1 group-hover:text-emerald-600 transition-colors">{item.name}</h4>
                    <p className="text-sm font-medium text-emerald-500/60 uppercase tracking-widest">{item.weight}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </section>
  );
}
