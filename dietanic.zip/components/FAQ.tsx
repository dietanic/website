'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'Where are we delivering? (Location)',
    answer: 'We are delivering up to 33 pin codes in Coimbatore, Tamil Nadu, India.',
  },
  {
    question: 'What about the delivery charges? (Charges)',
    answer: 'Standard shipping (free) is often included in your subscription commitment. Any additional "Customised Shipping" charges will be clearly displayed or communicated at online or offline checkout.',
  },
  {
    question: 'What time are we delivering? (Hours)',
    answer: 'Weekdays: 6:00 AM to 10:00 AM - Holidays: Sunday & Listed Public Holidays. For recurring meal or product kits, deliveries are scheduled based on your chosen frequency (daily, weekly, or monthly).',
  },
  {
    question: 'What are the accepted payment methods?',
    answer: 'To provide a seamless checkout experience, CULTLIV DIETANIC LLP accepts the following payment methods: Credit & Debit Cards: All major domestic and international cards (Visa, Mastercard, RuPay, Amex). UPI (Unified Payments Interface): Google Pay, PhonePe, Paytm, and other BHIM-supported apps. Net Banking: Secure transfers from all major Indian banks. Wallets: Select digital wallets as displayed at the time of checkout.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-emerald-600 font-semibold tracking-wide uppercase text-sm mb-3">Salad Delivery FAQs</h2>
          <p className="mt-2 text-4xl font-extrabold text-emerald-950 tracking-tight sm:text-5xl">
            Frequently Asked Questions
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.005, backgroundColor: 'rgba(16, 185, 129, 0.08)' }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: index * 0.1, ease: 'easeOut' }}
              className="border border-emerald-100 rounded-2xl overflow-hidden bg-emerald-50/30 transition-colors duration-300"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                aria-expanded={openIndex === index}
                aria-controls={`faq-answer-${index}`}
                id={`faq-question-${index}`}
                className="w-full flex items-center justify-between p-5 sm:p-6 text-left focus:outline-none group"
              >
                <span className="text-base sm:text-lg font-bold text-emerald-950 pr-4 group-hover:text-emerald-700 transition-colors">{faq.question}</span>
                <ChevronDown
                  className={`w-6 h-6 text-emerald-500 transition-transform duration-500 ease-in-out ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    id={`faq-answer-${index}`}
                    role="region"
                    aria-labelledby={`faq-question-${index}`}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 text-emerald-800/80 leading-relaxed">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
