'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calculator, Info, RefreshCw } from 'lucide-react';

export default function BMICalculator() {
  const [weight, setWeight] = useState<string>('');
  const [height, setHeight] = useState<string>('');
  const [bmi, setBmi] = useState<number | null>(null);
  const [category, setCategory] = useState<string>('');

  const calculateBMI = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100; // Convert cm to m

    if (w > 0 && h > 0) {
      const bmiValue = w / (h * h);
      setBmi(parseFloat(bmiValue.toFixed(1)));

      if (bmiValue < 18.5) setCategory('Underweight');
      else if (bmiValue < 25) setCategory('Normal weight');
      else if (bmiValue < 30) setCategory('Overweight');
      else setCategory('Obese');
    }
  };

  const reset = () => {
    setWeight('');
    setHeight('');
    setBmi(null);
    setCategory('');
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Normal weight': return 'text-emerald-600 bg-emerald-50';
      case 'Underweight': return 'text-blue-600 bg-blue-50';
      case 'Overweight': return 'text-orange-600 bg-orange-50';
      case 'Obese': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="bg-white rounded-3xl p-8 border border-emerald-100 shadow-xl h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
          <Calculator className="w-6 h-6 text-emerald-600" />
        </div>
        <h3 className="text-2xl font-bold text-emerald-950">BMI Calculator</h3>
      </div>

      <p className="text-emerald-800/60 text-sm mb-8 leading-relaxed">
        Body Mass Index (BMI) is a simple index of weight-for-height that is commonly used to classify underweight, overweight and obesity in adults.
      </p>

      <form onSubmit={calculateBMI} className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-bold text-emerald-900 ml-1">Weight (kg)</label>
            <input
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder="e.g. 70"
              className="w-full px-4 py-3 rounded-xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-emerald-900 ml-1">Height (cm)</label>
            <input
              type="number"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              placeholder="e.g. 175"
              className="w-full px-4 py-3 rounded-xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              required
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-emerald-500/20"
        >
          Calculate BMI
        </button>
      </form>

      <AnimatePresence>
        {bmi !== null && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="mt-8 p-6 rounded-2xl border border-emerald-50 bg-emerald-50/30"
          >
            <div className="flex justify-between items-center mb-4">
              <span className="text-emerald-900 font-bold">Your Result</span>
              <button onClick={reset} className="text-emerald-600 hover:text-emerald-700">
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex items-baseline gap-3 mb-4">
              <span className="text-4xl font-black text-emerald-950">{bmi}</span>
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${getCategoryColor(category)}`}>
                {category}
              </span>
            </div>

            <div className="flex items-start gap-2 text-xs text-emerald-800/60 bg-white/50 p-3 rounded-lg border border-emerald-100/50">
              <Info className="w-4 h-4 text-emerald-400 shrink-0" />
              <p>A healthy BMI range is between 18.5 and 24.9. Consult with a professional for a detailed health analysis.</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
